# Blog-Website
Blogs can be create, update, delete with logging user. Login system is created with new registration, login and profile page.

# Blog-Website Specifications
Home page contains Blogs with profile picture(logged user's profile pic), title of blog, username, blog post date and content of blog with pagination.
Profile picture and username are link which are transfer to only blogs which are created by specified user.
Blogs are updated and deleted only by author of that blog.
Profile is only changed by logging user.
